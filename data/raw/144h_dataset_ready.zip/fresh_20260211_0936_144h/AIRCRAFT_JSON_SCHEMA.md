# ✈️ Aircraft JSON Data Schema

## Overview
The `aircraft.json` file contains the real-time state of all tracked aircraft. This data is the source for the live map and is flattened into `_aircraft.csv` for historical logging.

## Top-Level Fields
| Field | Type | Description |
| :--- | :--- | :--- |
| **`now`** | Float | UNIX timestamp of the snapshot. |
| **`messages`** | Integer | Total message count for the session. |
| **`aircraft`** | Array | List of aircraft objects (see below). |

## Aircraft Object Fields
Each item in the `aircraft` array represents one tracked target.

### 1. Identity
| Field | Type | Description |
| :--- | :--- | :--- |
| **`hex`** | String | **Unique ID:** The 24-bit ICAO address (e.g., `461f39`). |
| **`flight`** | String | Callsign or Flight Number (e.g., `FIN4B`). |
| **`squawk`** | String | 4-digit Octal Transponder Code assigned by ATC (e.g., `0212`). |
| **`category`** | String | Emitter Category (e.g., `A1` = Light, `A5` = Heavy). |

### 2. Position & Movement
| Field | Type | Description |
| :--- | :--- | :--- |
| **`lat`**, **`lon`** | Float | Latitude and Longitude (Decimal Degrees). |
| **`alt_baro`** | Integer | Barometric Altitude (feet) at standard pressure (1013.25 hPa). |
| **`alt_geom`** | Integer | Geometric Altitude (feet) derived from GNSS (GPS). |
| **`gs`** | Float | Ground Speed (knots). |
| **`track`** | Float | Track Angle (degrees). Direction of movement. |
| **`baro_rate`** | Integer | Vertical Rate (feet/min). Positive = Climb, Negative = Descent. |
| **`nav_qnh`** | Float | Altimeter setting (hPa) broadcast by the aircraft. |
| **`nav_altitude_mcp`** | Integer | Autopilot "Selected Altitude" (the altitude the pilot *wants* to go to). |

### 3. Signal Quality (RF)
| Field | Type | Description |
| :--- | :--- | :--- |
| **`rssi`** | Float | **Signal Strength (dBFS):** Closer to 0 is stronger. <br>-5 = Very Strong (Close)<br>-30 = Weak (Far) |
| **`seen`** | Float | Seconds since the last message was received. |
| **`messages`** | Integer | Total messages received from this specific aircraft. |

### 4. Integrity & Accuracy (NIC/NAC/SIL)
*Crucial for Safety & Validation*
| Field | Type | Description |
| :--- | :--- | :--- |
| **`nic`** | Integer | **Nav Integrity Category (0-11):** Bounds the "Containment Radius". <br>11 = < 7.5 meters (Precision Approach)<br>0 = Unknown integrity |
| **`rc`** | Integer | **Radius of Containment (meters):** Derived from NIC. "The aircraft is definitely within X meters of this position." |
| **`sil`** | Integer | **Source Integrity Level (0-3):** Probability of exceeding the containment radius. <br>3 = Very High Integrity (10^-7/hr) |
| **`nac_p`** | Integer | **Nav Accuracy Category (Position):** Estimated position uncertainty (95%). |
| **`version`** | Integer | ADS-B Version (0, 1, or 2). Version 2 supports higher precision. |

### 5. Status Flags
| Field | Type | Description |
| :--- | :--- | :--- |
| **`emergency`** | String | Emergency status. Values: `none`, `general`, `lifeguard`, `minfuel`, `nordo`, `unlawful`, `downed`. |
| **`mlat`** | Array | List of fields derived from Multilateration (time-difference of arrival) rather than ADS-B data. |
| **`tisb`** | Array | List of fields sourced from TIS-B (Traffic Information Service - Broadcast). |
