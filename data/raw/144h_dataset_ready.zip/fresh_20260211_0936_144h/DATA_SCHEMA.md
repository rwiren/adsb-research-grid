# 📊 SecuringSkies Data Schema

Documentation of dataset fields for ADS-B, Hardware, and Stats logs.

## `west_aircraft.csv`
*Total Rows Analyzed: 102064*

| Column | Type | Description | Example |
| :--- | :--- | :--- | :--- |
| **timestamp** | `String` | UTC Timestamp. | `2026-02-11T00:00:00.959063+00:00` |
| **hex** | `String` | Unique ICAO 24-bit aircraft address (Hexadecimal). | `461f39` |
| **flight** | `String` | Callsign or Flight Number (e.g., FIN4B). | `FIN4B` |
| **squawk** | `Float` | 4-digit Octal Transponder Code assigned by ATC. | `212.0` |
| **emergency** | `String` | Emergency status (e.g., 'none', 'general', 'lifeguard'). | `none` |
| **lat** | `Float` | Latitude in decimal degrees. | `59.532166` |
| **lon** | `Float` | Longitude in decimal degrees. | `21.594291` |
| **alt_baro** | `Float` | Barometric Altitude (feet) at standard pressure. | `25975.0` |
| **alt_geom** | `Float` | Geometric Altitude (feet) (GPS-derived). | `37000.0` |
| **gs** | `Float` | Ground Speed (knots). | `378.0` |
| **track** | `Float` | Track angle (degrees). | `2.46` |
| **baro_rate** | `Float` | Vertical Rate (feet/minute). | `1984.0` |
| **rssi** | `Float` | Signal Strength (dBFS). Closer to 0 is stronger. | `-33.2` |
| **nic** | `Float` | Navigation Integrity Category (0-11). | `8.0` |
| **rc** | `Float` | Radius of Containment (meters). | `186.0` |
| **sil** | `Float` | Source Integrity Level (0-3). | `0.0` |
| **nac_p** | `Float` | Navigation Accuracy Category for Position. | `0.0` |
| **nav_qnh** | `Float` | Altimeter setting (hPa). | `1013.0` |
| **nav_altitude_mcp** | `Float` | Autopilot selected altitude (feet). | `38000.0` |
| **seen** | `Float` | Seconds since last message. | `4.5` |

---

## `west_stats.csv`
*Total Rows Analyzed: 457*

| Column | Type | Description | Example |
| :--- | :--- | :--- | :--- |
| **timestamp** | `String` | UTC Timestamp. | `2026-02-11T00:00:01.044995+00:00` |
| **messages_total** | `Integer` | Cumulative Mode S messages received. | `15296268` |
| **aircraft_tracked** | `Integer` | Number of aircraft currently tracked. | `2` |
| **cpu_temp** | `Float` | CPU Temperature (Celsius). | `29.693` |
| **signal_level** | `Float` | Average Signal Level (dBFS). | `-30.3` |
| **noise_level** | `Float` | Noise Floor (dBFS). | `-39.2` |
| **peak_signal** | `Float` | Peak Signal (dBFS). | `-26.5` |
| **max_distance** | `Integer` | Max range to aircraft (meters). | `0` |
| **samples_dropped** | `Integer` | Samples dropped (USB overload indicator). | `0` |

---

## `west_hardware.csv`
*Total Rows Analyzed: 7336*

| Column | Type | Description | Example |
| :--- | :--- | :--- | :--- |
| **Timestamp** | `Float` | Raw data field. | `40.9` |
| **Temp_C** | `String` | CPU Temperature (Celsius). | `0x0` |
| **Throttled_Hex** | `Integer` | Throttle State Hex Code (0x0=OK, 0x50000=Throttling). | `1500345728` |
| **Clock_Arm_Hz** | `String` | CPU Frequency in Hz. | `up 13 hours` |
| **Uptime** | `String` | System uptime string (Raw Linux output). | ` 28 minutes` |

---

## `north_gold.ubx_converted.csv`
*Total Rows Analyzed: 7828*

| Column | Type | Description | Example |
| :--- | :--- | :--- | :--- |
| **timestamp** | `Float` | UTC Timestamp. | `95301.0` |
| **lat** | `Float` | Latitude in decimal degrees. | `60.31947333333333` |
| **lon** | `Float` | Longitude in decimal degrees. | `24.8308435` |
| **hMSL** | `Float` | Raw data field. | `83.8` |
| **fixType** | `Integer` | Raw data field. | `2` |

---

