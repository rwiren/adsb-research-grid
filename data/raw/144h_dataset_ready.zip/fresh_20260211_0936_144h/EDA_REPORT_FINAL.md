# 🔬 Scientific Data Report: 144-Hour Collection
**Analysis Generated:** 2026-02-11 10:50

## 1. Timeline & Volume
| Sensor | Start (UTC) | End (UTC) | Total Rows | Unique Aircraft |
| :--- | :--- | :--- | :--- | :--- |
| **NORTH** | 02-11 00:00 | 02-11 07:36 | 557,267 | 160 |
| **WEST** | 02-11 00:00 | 02-11 07:36 | 102,064 | 101 |
| **EAST** | 02-11 00:00 | 02-11 07:36 | 228,509 | 140 |

## 2. Hardware Health Check
Status of Power Supply and Thermal Management during the 144h run.

| Sensor | Avg Temp | Power Status | Verdict |
| :--- | :--- | :--- | :--- |
| **NORTH** | 45.4°C | ✅ PERFECT | ✅ PERFECT |
| **WEST** | 35.2°C | ✅ PERFECT | ✅ PERFECT |
| **EAST** | 41.9°C | ✅ PERFECT | ✅ PERFECT |

## 3. Signal Sensitivity Analysis
Analysis of 'Missing Position' data. Higher missing % often indicates higher sensitivity to weak/distant Mode-S signals.

| Sensor | Avg Signal (RSSI) | Missing Position | % Missing | Interpretation |
| :--- | :--- | :--- | :--- | :--- |
| **NORTH** | -25.0 dB | 318,982 | **57.2%** | Standard |
| **WEST** | -28.4 dB | 46,314 | **45.4%** | Low Sensitivity (Strong Targets Only) |
| **EAST** | -28.5 dB | 160,605 | **70.3%** | High Sensitivity (Distant Targets) |

## 4. Flight Extremes
- **Fastest Target:** 682.4 kts (NORTH)
- **Highest Target:** 41,000.0 ft (NORTH)
