# 🚜 Data Collection Methodology

## The "Snapshot" Harvester
The data in this package was collected using a custom distributed slicing script (`harvest_v3.sh`). 

### Why CSV and not JSON?
While the sensors broadcast live JSON, storing raw JSON for 144+ hours is storage-inefficient due to repetitive field names.
1. **On-Sensor Logging:** A background service flattens the JSON stream into **CSV format** in real-time. This reduces storage footprint by ~60%.
2. **The Harvest Script:** Instead of transferring gigabytes of logs, the script connects via SSH to all three nodes simultaneously and performs a **"Time Slice"**:
   - It identifies the active log file.
   - It extracts the Header (Line 1).
   - It extracts the last $ lines (based on requested hours).
   - It zips the slice on the sensor before transfer to ensure low latency.

### Sensor Architecture
* **Sensor-North (Reference):** u-blox F9P (RTK GNSS) + FlightAware Pro Stick.
* **Sensor-West (Test):** Generic RTL-SDR (No Filter). Used to measure GSM/LTE interference.
* **Sensor-East (Baseline):** FlightAware Pro Stick (Filtered). 

### File Structure
* **`_aircraft.csv`**: Flight path vectors (Lat, Lon, Alt, Speed).
* **`_stats.csv`**: Receiver RF health (Signal Level, Noise Floor, Gain).
* **`_hardware.csv`**: System health (CPU Temp, Throttling, Uptime).
