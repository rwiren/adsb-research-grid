DATASET: 144-Hour Continuous ADS-B Collection
DURATION: Feb 5, 2026 - Feb 11, 2026 (~6 Days)
---------------------------------------------------------
SENSORS:
1. NORTH (Reference): Includes High-Precision RTK Data.
   - Source: u-blox F9P (north_gold.ubx)
   - Converted: north_rtk.csv (CSV format for team analysis)
   
2. WEST: Standard RTL-SDR (No Filter). 
   - Good for analyzing GSM/LTE interference levels.

3. EAST: FlightAware Blue Stick (Filtered).
   - High-fidelity 1090MHz reference.

FILES:
- *_aircraft.csv: Decoded ADS-B messages.
- *_hardware.csv: CPU/Temp/Gain stats.
- north_rtk.csv:  Centimeter-level GNSS logs for truth data.

NOTES:
- 'north_gnss.csv' was found empty and replaced by 'north_rtk.csv'.
- Obsolete intermediate zip files have been removed.

TOOLS:
- convert_rtk.py: Python script included to re-convert the .ubx file if needed.
  Usage: python3 convert_rtk.py north_gold.ubx
