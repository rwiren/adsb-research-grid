# 📊 Receiver Performance Schema (stats.json/csv)

This document explains the technical fields found in the `_stats.csv` and `stats.json` logs. These metrics are critical for analyzing the RF environment.

## 1. Top-Level RF Metrics (Key Indicators)
| Field | Unit | Description | Ideal Range |
| :--- | :--- | :--- | :--- |
| **`signal_level`** | dBFS | Average Signal Strength. Closer to 0 is stronger. | -5 to -25 dBFS |
| **`noise_level`** | dBFS | Noise Floor. Lower is better. | -30 to -40 dBFS |
| **`peak_signal`** | dBFS | Strongest signal received. If > -3dB, the receiver is saturating (Gain too high). | < -3 dBFS |
| **`gain_db`** | dB | The amplifier gain setting of the SDR. | 40-49 dB |

## 2. Processing & Integrity
| Field | Description |
| :--- | :--- |
| **`samples_processed`** | Total RF samples read from the USB SDR. |
| **`samples_dropped`** | **CRITICAL:** Number of samples lost due to CPU overload or USB bandwidth issues. Should be 0. |
| **`messages_total`** | Total Mode S messages detected (before error correction). |
| **`messages_valid`** | Messages successfully decoded (CRC Check passed). |
| **`strong_signals`** | Count of signals that exceeded the dynamic range of the receiver (clipping). |

## 3. Tracking Logic
| Field | Description |
| :--- | :--- |
| **`aircraft_with_pos`** | Number of aircraft currently tracked with a valid GPS solution. |
| **`aircraft_without_pos`** | Aircraft tracked via Mode S only (no GPS position decoded yet). |
| **`max_distance`** | The furthest distance (meters) to a tracked target in this time window. |

## 4. CPR (Compact Position Reporting) Stats
*Used to debug decoding efficiency*
| Field | Description |
| :--- | :--- |
| **`cpr.global_ok`** | Positions solved using Global CPR (requires 2 messages, even/odd). |
| **`cpr.local_ok`** | Positions solved using Local CPR (requires a known reference position). |
| **`cpr.filtered`** | Positions discarded because they were physically impossible (e.g., jumping 50km in 1 second). |

## 5. CPU Utilization
| Field | Description |
| :--- | :--- |
| **`cpu.demod`** | Time (ms) spent demodulating the signal (Signal Processing). |
| **`cpu.reader`** | Time (ms) spent reading raw data from USB. |
| **`cpu.background`** | Time (ms) spent on network and housekeeping tasks. |
