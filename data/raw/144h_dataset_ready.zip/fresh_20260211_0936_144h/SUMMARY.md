# 🛸 SecuringSkies: 144-Hour Research Dataset
**Project:** Academic Scientific Research regarding ADS-B Spoofing
**Data Range:** 2026-02-05 to 2026-02-11

## 📂 Quick Start Guide
1. **The Data:** Look in `*_aircraft.csv` for decoded flight vectors.
2. **The Truth:** Use `north_gold.ubx_converted.csv` for the high-precision RTK ground truth.
3. **The Proof:** Read `EDA_REPORT_FINAL.md` to see why Sensor-East (Filtered) outperformed Sensor-West (Unfiltered).
4. **The Schemas:** Detailed field definitions are in `DATA_SCHEMA.md` and `STATS_SCHEMA.md`.

## 🛠 Included Tools
- `convert_universal.py`: Python tool to re-parse the raw GNSS .ubx (NMEA) logs if needed.
- `convert_rtk.py`: Binary UBX parser for u-blox F9P specific messages.

## 📡 Sensor Overview
- **NORTH:** Reference station with u-blox F9P (RTK).
- **WEST:** Test station with unfiltered silver RTL-SDR.
- **EAST:** Baseline station with blue FlightAware filtered stick.
