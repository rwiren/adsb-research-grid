import sys
import pandas as pd
import os
from pyubx2 import UBXReader

def parse_ubx(file_path):
    if not os.path.exists(file_path):
        print(f"❌ Error: File not found: {file_path}")
        return

    print(f"🔄 Parsing binary UBX: {file_path}...")
    data = []
    
    with open(file_path, 'rb') as f:
        ubr = UBXReader(f)
        for (raw_data, parsed_data) in ubr:
            if parsed_data.identity == 'NAV-PVT':
                ts = pd.Timestamp(
                    year=parsed_data.year, month=parsed_data.month, day=parsed_data.day,
                    hour=parsed_data.hour, minute=parsed_data.min, second=parsed_data.sec
                )
                data.append({
                    'timestamp': ts,
                    'lat': parsed_data.lat,
                    'lon': parsed_data.lon,
                    'hMSL': parsed_data.hMSL / 1000.0,
                    'fixType': parsed_data.fixType,
                    'numSV': parsed_data.numSV
                })

    df = pd.DataFrame(data)
    if not df.empty:
        output_file = file_path.replace('.ubx', '_converted.csv')
        df.to_csv(output_file, index=False)
        print(f"✅ Success! Converted {len(df)} points to {output_file}")
    else:
        print("⚠️ Warning: No NAV-PVT data found in UBX file.")

if __name__ == "__main__":
    # Checks current folder first
    parse_ubx("sensor-north_gold.ubx")
