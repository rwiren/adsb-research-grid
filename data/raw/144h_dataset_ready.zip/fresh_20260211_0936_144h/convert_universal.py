import sys
import pandas as pd
import os

def parse_gnss(file_path):
    if not os.path.exists(file_path):
        print(f"❌ Error: File not found: {file_path}")
        return

    print(f"🔄 Scanning {file_path} for NMEA (Text) or UBX (Binary)...")
    data = []
    
    # Try parsing as NMEA Text first (since your error showed GNGGA)
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                if 'GGA' in line and line.startswith('$'):
                    # Parse NMEA /
                    parts = line.strip().split(',')
                    if len(parts) < 10: continue
                    
                    try:
                        # Time HHMMSS.SS
                        ts_str = parts[1]
                        
                        # Latitude
                        if not parts[2]: continue
                        lat_raw = float(parts[2])
                        lat = int(lat_raw/100) + (lat_raw%100)/60
                        if parts[3] == 'S': lat = -lat
                        
                        # Longitude
                        if not parts[4]: continue
                        lon_raw = float(parts[4])
                        lon = int(lon_raw/100) + (lon_raw%100)/60
                        if parts[5] == 'W': lon = -lon
                        
                        # Altitude
                        alt = float(parts[9]) if parts[9] else 0.0
                        
                        # Quality (4=RTK Fixed)
                        qual = int(parts[6]) if parts[6] else 0
                        
                        data.append({
                            'timestamp': ts_str,
                            'lat': lat, 
                            'lon': lon, 
                            'hMSL': alt, 
                            'fixType': qual
                        })
                    except:
                        continue
    except Exception as e:
        print(f"Read error: {e}")

    # Export
    if data:
        df = pd.DataFrame(data)
        output = file_path + "_converted.csv"
        df.to_csv(output, index=False)
        print(f"✅ Success! Extracted {len(df)} NMEA points to {output}")
        # Quick Stat Check
        rtk_fixes = df[df['fixType'] == 4].shape[0]
        print(f"   (RTK Fixed Points: {rtk_fixes})")
    else:
        print("❌ Failed. No NMEA (GNGGA) data found.")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        parse_gnss(sys.argv[1])
    else:
        parse_gnss("north_gold.ubx")
